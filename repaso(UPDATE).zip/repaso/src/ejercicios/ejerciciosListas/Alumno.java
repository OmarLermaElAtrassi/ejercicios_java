package ejercicios.ejerciciosListas;

public record Alumno(String nombre, String apellidos, String fechaNacimiento, String dni) {
    @Override
    public String nombre() {
        return nombre;
    }

    @Override
    public String apellidos() {
        return apellidos;
    }

    @Override
    public String fechaNacimiento() {
        return fechaNacimiento;
    }

    @Override
    public String dni() {
        return dni;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s",dni,apellidos,nombre,fechaNacimiento);
    }
}
