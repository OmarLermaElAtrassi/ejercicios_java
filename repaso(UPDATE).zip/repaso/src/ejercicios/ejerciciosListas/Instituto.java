package ejercicios.ejerciciosListas;

import java.time.LocalDate;
import java.util.ArrayList;


public class Instituto {
    private String nombreInsti;
    ArrayList<Alumno> alumnos;

    @Override
    public String toString() {
        return "Instituto{" +
                "alumnos=" + alumnos +
                '}';
    }
    public void añadirAlumnos(Alumno alumno){
        alumnos.add(alumno);
    }

    public void buscarPorDni(String dni){
        for (int i = 0; i < alumnos.size(); i++) {
            if (alumnos.get(i).dni().equals(dni))
                alumnos.get(i);
        }
    }
    public void eliminarPorDni(String dni){
        for (int i = 0; i < alumnos.size(); i++) {
            if (alumnos.get(i).dni().equals(dni))
                alumnos.remove(i);
        }
    }
    public String obtenerTodosAlumnos(){
        return toString();
    }
}
