package examen2.ejercicio1;

public class Libro {
    private String titulo;
    private String autor;
    private String isbn;
    private Enum tematica;

    public Libro(String titulo, String autor, String isbn, Tematica tematica) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.tematica = tematica;
    }
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public Enum getTematica() {
        return tematica;
    }

    @Override
    public String toString() {
        return String.format("%s,%s,%s,%s", titulo,autor,isbn,tematica);
    }
}
