package examen2.ejercicio1;

public enum Tematica {
    LITERATURA, CIENCIAS, TECNOLOGIA
}
