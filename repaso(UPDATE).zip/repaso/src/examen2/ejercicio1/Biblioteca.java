package examen2.ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private String nombreBiblio;
    private List<Libro> libros;

    public Biblioteca(String nombreBiblio, List<Libro> libros) {
        this.nombreBiblio = nombreBiblio;
        this.libros = libros;
    }

    public String getNombreBiblio() {
        return nombreBiblio;
    }

    public void setNombreBiblio(String nombreBiblio) {
        this.nombreBiblio = nombreBiblio;
    }

    public List<Libro> getLibros() {
        return libros;
    }

    public void setLibros(List<Libro> libros) {
        this.libros = libros;
    }
    public boolean insertarLibro(Libro libro){

        return libros.add(libro);
    }
    public boolean eliminarLibro(String isbn){
        for (Libro libro : libros)
            if (libro.getIsbn().equals(isbn))
                return libros.remove(libro);
        return false;
    }
    public Libro buscarPorIsbn(String isbn) {
        for (Libro libro : libros){
            if (libro.getIsbn().equals(isbn))
                return libro;
        }
        return null;
    }
        public List<Libro> buscarPorTematica(Enum tematica){
        List<Libro> listaLibrosTematica = new ArrayList<>();
        for (Libro libro : libros)
            if (libro.getTematica().equals(tematica))
                listaLibrosTematica.add(libro);
        return listaLibrosTematica;
    }
    public List<Libro> buscarPorIdioma (int id){
        List<Libro> listaIdiomas = new ArrayList<>();
        String opcion = "";
        if (id == 1)
            opcion = "0";
        if (id == 2)
            opcion = "84";
        for (Libro libro2 : libros){
            if (libro2.getIsbn().startsWith(opcion)){
                listaIdiomas.add(libro2);
            }
        }
        if (listaIdiomas.isEmpty())
            return null;
        else return listaIdiomas;
    }
    @Override
    public String toString() {
        StringBuilder biblio = new StringBuilder();
        biblio.append(nombreBiblio).append("\n").append("===============\n");
        int indice = 1;
        for (Libro libro2 : libros){
            biblio.append(indice++).append(".").append(libro2.toString()).append('|');
        }

        return biblio.toString();
    }
}

