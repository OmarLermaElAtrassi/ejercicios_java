package examen2.ejercicio1;

public class Helper {
    String tema;
    String isbn;
    public static Boolean comprobarTema(String tema){
        if (tema.equals(null) || tema.equals(""))
            return false;
        if (tema.toLowerCase().matches("ciencias|tecnolog[ií]a|literatura"))
            return true;
        else
            return false;
    }
    public static Boolean comprobarIsbn(String isbn){
        if ( isbn.equals(null) || isbn.equals(""))
            return false;
        if (isbn.matches("0[0-9]{9}|84[0-9]{8}]"))
            return true;
        else
            return false;
    }

}
