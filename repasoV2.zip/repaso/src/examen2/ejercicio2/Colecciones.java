package examen2.ejercicio2;

import java.util.*;
import java.lang.StringBuilder;
import java.lang.Integer;

public class Colecciones {
    public static int[] invertirArray (int[] coleccionEnteros){
        int[] invertido = new int[coleccionEnteros.length];
        for (int i = 0, j = coleccionEnteros.length-1 ; i < coleccionEnteros.length ; i++, j--) {
            invertido[i] = coleccionEnteros[j];
        }
        return invertido;
    }
    public static String concatenarConSeparador (String[] coleccionCadenas, char separador){
        if (coleccionCadenas == null )
            return null;
        StringBuilder concatenada = new StringBuilder();
        for (int i = 0; i < coleccionCadenas.length; i++) {
            concatenada.append(coleccionCadenas [i]).append(separador);
        }
        if (coleccionCadenas.equals(""))
            return "";
        return concatenada.toString().substring(0, concatenada.length()-1);
    }

    public static double[] devolverComunes(double[] coleccionDobles1,double[] coleccionDobles2 ){
        Set<Double> coleccion3 =new HashSet<>();
        Arrays.sort(coleccionDobles2); //es necesario ordenar arrays para binary search
        for (int i = 0; i < coleccionDobles1.length; i++) {
            int posicion = Arrays.binarySearch(coleccionDobles2, coleccionDobles1[i]);
            if (posicion >= 0)
                coleccion3.add(coleccionDobles1[i]);
        }
        double [] comunes = new double[coleccion3.size()];
        int index = 0;
        for (double comun : coleccion3) {
            comunes[index++] = comun;
        }
        return comunes;
    }
    public static int[] devolverMayorYMenor(int[] coleccionEnteros){
        int numeroMayor =Integer.MIN_VALUE;
        int numeroMenor = Integer.MAX_VALUE;
        for (int entero : coleccionEnteros){
            if (numeroMayor >= entero)
                numeroMayor = entero;
            if (numeroMenor <= entero)
                numeroMenor = entero;
        }
        int[] numerosMayorYMenor = {numeroMayor, numeroMenor};
        return numerosMayorYMenor;
    }

    public static void main(String[] args) {
        /*String[] arrayString = {};
        char separador = '`';*/
        int [] enteros = {1,2,3,4};
        //String cadenaconcatenada=concatenarConSeparador(arrayString,separador);
        //System.out.println(cadenaconcatenada);
        System.out.println(Arrays.toString(invertirArray(enteros)));
    }
}
