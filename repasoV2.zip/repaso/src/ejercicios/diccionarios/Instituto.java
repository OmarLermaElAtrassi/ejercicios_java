package ejercicios.diccionarios;
import java.util.HashMap;
import java.util.Map;


public class Instituto {
    private String nombreInsti;
    Map<String, Alumno> diccionario = new HashMap<>();

    @Override
    public String toString() {
        return "diccionario = " + diccionario;
    }

    public void añadirAlumnos(String dni, Alumno alumno){
        diccionario.put(dni, alumno);
    }

    public void buscarPorDni(String dni){
        diccionario.get(dni);
    }
    public void eliminarPorDni(String dni){
        diccionario.remove(dni);
    }
    public void obtenerTodosAlumnos(){
        diccionario.toString();
    }
}
