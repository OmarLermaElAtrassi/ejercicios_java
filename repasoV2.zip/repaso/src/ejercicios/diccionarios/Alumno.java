package ejercicios.diccionarios;

public record Alumno(String nombre, String apellidos, String fechaNacimiento) {
    @Override
    public String nombre() {
        return nombre;
    }

    @Override
    public String apellidos() {
        return apellidos;
    }

    @Override
    public String fechaNacimiento() {
        return fechaNacimiento;
    }
    @Override
    public String toString() {
        return String.format("%s,%s,%s",apellidos,nombre,fechaNacimiento);
    }
}
