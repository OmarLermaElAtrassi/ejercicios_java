package ejercicios.ejerciciosArrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.random.RandomGenerator;

public class AnalisisDatos {

    public static double getMedia(int[] numerosEnteros){
        int sumaNumeros = 0;
        for (int numero : numerosEnteros){
            sumaNumeros += numero;
        }
        return 1.0 * sumaNumeros / (numerosEnteros.length );
    }
    public static int [] getNuevoArray(int[] numerosEnteros){
        int mayor = 0;
        for (int numero : numerosEnteros){
            if (numero >= mayor)
                mayor = numero;
        }
        int menor = mayor;
        for (int numero : numerosEnteros){
            if (numero <= menor)
                menor = numero;
        }
        int[] nuevoArray = {menor, mayor};
        return nuevoArray;
    }
    public static double getDesviacionTipica (int [] numerosEnteros){
        double suma = 0;
        double media = getMedia(numerosEnteros);
        for (int i = 0; i < numerosEnteros.length; i++) {
            suma += Math.pow((numerosEnteros[i] - media), 2);
        }
        return Math.sqrt(suma / (numerosEnteros.length -1));
    }
    public static int getValorAleatorio (int[] numerosEnteros){
        Random aleatorio = new Random();
        return numerosEnteros[aleatorio.nextInt(0, numerosEnteros.length -1)];
    }
}
