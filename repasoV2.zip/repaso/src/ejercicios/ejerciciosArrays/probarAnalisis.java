package ejercicios.ejerciciosArrays;

import java.util.Arrays;

public class probarAnalisis {
    public static void main(String[] args) {
        int [] numerosEnteros = {1,123,326,6,345,6,3,24,623,6664345,76536734,};
        System.out.println("MEDIA = " + AnalisisDatos.getMedia(numerosEnteros)+ ", NUEVO ARRAY = " +
                Arrays.toString(AnalisisDatos.getNuevoArray(numerosEnteros)) + ", DESVIACION = "+
                AnalisisDatos.getDesviacionTipica(numerosEnteros) + ", VALOR ALEATORIO = " +
                AnalisisDatos.getValorAleatorio(numerosEnteros));
    }
}
