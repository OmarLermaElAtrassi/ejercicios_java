package ejercicios.ejerciciosListas;

import java.time.LocalDate;
import java.util.Locale;

public record Alumno(String nombre, String apellidos, LocalDate fechaNacimiento, String dni) {
    @Override
    public String nombre() {
        return nombre;
    }

    @Override
    public String apellidos() {
        return apellidos;
    }

    @Override
    public LocalDate fechaNacimiento() {
        return fechaNacimiento;
    }

    @Override
    public String dni() {
        return dni;
    }


    @Override
    public String toString() {
        int anno = fechaNacimiento.getYear();
        int mes = fechaNacimiento.getMonthValue();
        int dia = fechaNacimiento.getDayOfMonth();
        return String.format("%s,%s,%s,%d/%d/%d",dni,apellidos,nombre,dia, mes, anno);
    }
}
