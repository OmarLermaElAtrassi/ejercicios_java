package ejercicios.ejerciciosListas;

import examen2.ejercicio1.Biblioteca;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;


public class Instituto {
    private String nombreInsti;
    List<Alumno> alumnos;

    public Instituto(String nombreInsti, List<Alumno> alumnos) {
        this.nombreInsti = nombreInsti;
        this.alumnos = alumnos;
    }

    @Override
    public String toString() {
        return "Instituto{" +
                "alumnos=" + alumnos +
                '}';
    }
    public boolean añadirAlumnos(Alumno alumno){

        return alumnos.add(alumno);
    }

    public Alumno buscarPorDni(String dni){
        for (Alumno alumno : alumnos){
            if (alumno.dni().equals(dni))
                return alumno;
        }
        return null;
    }
    public boolean eliminarPorDni(String dni){
        for (Alumno alumno : alumnos)
            if (alumno.dni().equals(dni))
                return alumnos.remove(alumno);
        return false;
    }
    public String obtenerTodosAlumnos(){
        StringBuilder concatenada = new StringBuilder();
        for (int i = 0; i <alumnos.size(); i++) {
            concatenada.append(alumnos.get(i).toString());
            if (i < alumnos.size() -1)
                concatenada.append('|');
        }
        return concatenada.toString();
    }
    public List<Alumno> obtenerMayoresEdad(){
        List<Alumno> mayores = new ArrayList<>();
        LocalDate hoy = LocalDate.now();
        Period periodo;
        for (Alumno mayor : alumnos)

            if (periodo.getYears(mayor.fechaNacimiento()) > 18)
    }
}
