package examen2.ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private String nombreBiblio;
    private List<Libro> libros = new ArrayList<>();

    public Biblioteca(String nombreBiblio, List<Libro> libros) {
        this.nombreBiblio = nombreBiblio;
        this.libros = libros;
    }

    public String getNombreBiblio() {
        return nombreBiblio;
    }

    public void setNombreBiblio(String nombreBiblio) {
        this.nombreBiblio = nombreBiblio;
    }

    public List<Libro> getLibros() {
        return libros;
    }

    public void setLibros(List<Libro> libros) {
        this.libros = libros;
    }
    public void insertarLibro(Libro libro){
        libros.add(libro);
    }
    public void eliminarLibro(Libro libro){
        libros.remove(libro);
    }
    public void buscarPorIsbn(String isbn){
        for (int i = 0; i <libros.size(); i++) {
            if (libros.get(i).getIsbn().equals(isbn))
                libros.get(i);
        }
    }
    public void buscarPorTematica(String tematica){
        for (int i = 0; i <libros.size(); i++) {
            if (libros.get(i).getTematica().equals(tematica))
                libros.get(i);
        }
    }
}

