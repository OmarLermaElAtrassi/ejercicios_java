package examen2.ejercicio1;

public class Helper {
    String tema;
    String isbn;
    public static Boolean comprobarTema(String tema){
        if (tema.equals(null) || tema.equals(""))
            return null;
        if (tema.toLowerCase().equals("literatura") || tema.toLowerCase().equals("ciencias")||
        tema.toLowerCase().equals("tecnologia") || tema.toLowerCase().equals("tecnología"))
            return true;
        else
            return false;
    }
    public static Boolean comprobarIsbn(String isbn){
        if ( isbn.equals(null) || isbn.equals(""))
            return null;
        if (isbn.matches("0[0-9]{9}") || isbn.matches("84[0-9]{8}"))
            return true;
        else
            return false;
    }

}
