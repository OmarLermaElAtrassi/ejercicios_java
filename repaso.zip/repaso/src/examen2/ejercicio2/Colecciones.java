package examen2.ejercicio2;

import java.util.Arrays;
import java.lang.StringBuilder;
import java.lang.Integer;

public class Colecciones {
    public static int[] invertirArray (int[] coleccionEnteros){
        int[] invertido = new int[coleccionEnteros.length];
        for (int i = 0, j = coleccionEnteros.length-1 ; i < coleccionEnteros.length ; i++, j--) {
            invertido[i] = coleccionEnteros[j];
        }
        return invertido;
    }
    public static String concatenarConSeparador (String[] coleccionCadenas, char separador){
        StringBuilder concatenada = new StringBuilder();
        for (String cadena : coleccionCadenas){
            concatenada.append(cadena);
            concatenada.append(separador);
        }
        return concatenada.toString();
    }

    public static double[] devolverComunes(double[] coleccionDobles1,double[] coleccionDobles2 ){

    }
    public static int[] devolverMayorYMenor(int[] coleccionEnteros){
        int numeroMayor =Integer.MIN_VALUE;
        int numeroMenor = Integer.MAX_VALUE;
        for (int entero : coleccionEnteros){
            if (numeroMayor >= entero)
                numeroMayor = entero;
            if (numeroMenor <= entero)
                numeroMenor = entero;
        }
        int[] numerosMayorYMenor = {numeroMayor, numeroMenor};
        return numerosMayorYMenor;
    }
}
